# 🌿 OUTROOT — מגדיר הצמחים

**We dig it.**

כלי אינטרקטיבי לבחירת צמחים לפני פגישת הקמת גינה.

## 🚀 שימוש

שלח ללקוח את הקישור:
**https://[שם-המשתמש-שלך].github.io/outroot**

הלקוח:
1. דפדף בין 100+ צמחים עם תמונות
2. סנן לפי שמש/צל/מים
3. חפש בעברית חופשית עם AI
4. סמן מה אהב
5. לחץ "שלח ל-OUTROOT" — נפתח וואטסאפ ישירות אליך

## 📁 קבצים

- `index.html` — הכלי המלא
- `download_images.py` — הורדת תמונות להטמעה (הרץ פעם אחת)

## 🛠️ התקנה

```bash
git clone https://github.com/[username]/outroot
cd outroot

# הורד תמונות והטמע בקובץ
pip install requests
python download_images.py

# העלה לגיט
git add .
git commit -m "תמונות מוטמעות"
git push
```

## ⚡ GitHub Pages

1. Settings → Pages
2. Source: main branch / root
3. הקישור יהיה: `https://[username].github.io/outroot`

---
OUTROOT © 2026 | ירדן | עוטף ישראל
