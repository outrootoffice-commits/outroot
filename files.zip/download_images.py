"""
OUTROOT - סקריפט הורדת תמונות
הרץ אותו על המחשב שלך:
  pip install requests Pillow
  python download_images.py
"""

import requests, base64, re, json, time
from pathlib import Path

# כל ה-URLs שפוצחו מה-QR codes
PLANT_URLS = {
    "קופניופסיס אנקארדיואידיס": "https://bennigan-nursery.co.il/wp-content/smush-webp/2024/11/%D7%A7%D7%95%D7%A4%D7%A0%D7%99%D7%95%D7%9F-2.jpg.webp",
    "גייגרה פלוריבונדה": "https://spectrees.s3-ap-southeast-2.amazonaws.com/9476-2b84d2946b/conversions/geijera-parviflora-medium.jpg",
    "פודוקרפוס עדין": "https://www.moonvalleynurseries.com/_next/image?url=https%3A%2F%2Fwww.moonvalleynurseries.com%2Fimages%2Fplants%2Fpodocarpus-gracilior.jpg&w=640&q=75",
    "הרפפילום כפרי": "https://suntrees.co.za/wp-content/uploads/2017/01/Harpephyllum-caffrum.jpg",
    "אגוניס גמיש": "https://www.gardenia.net/wp-content/uploads/2023/11/agonis-flexuosa.webp",
    "ברכיכיטון צפצפתי": "https://www.gardenia.net/wp-content/uploads/2023/11/brachychiton-populneus.webp",
    "הימנוספורום צהוב": "https://www.gardenia.net/wp-content/uploads/2023/11/hymenosporum-flavum.webp",
    "קינמונום קמפורה": "https://www.gardenia.net/wp-content/uploads/2023/11/cinnamomum-camphora.webp",
    "ליגוסטרום יפני": "https://caraghnurseries.ie/wp-content/uploads/2024/04/Ligustrum-japonicum-Aureum-Standard.jpg",
    "מגנוליה גדולת פרחים": "https://www.evergreentrees.com.au/cdn/shop/files/Magnoliagrandi.jpg",
    "חרוב מצוי": "https://www.gardenia.net/wp-content/uploads/2023/11/ceratonia-siliqua.webp",
    "ער אציל": "https://www.gardenia.net/wp-content/uploads/2023/11/laurus-nobilis.webp",
    "זית ברנע": "https://www.gardenia.net/wp-content/uploads/2023/11/olea-europaea.webp",
    "אלביציה ורודה": "https://www.gardenia.net/wp-content/uploads/2023/11/albizia-julibrissin.webp",
    "כליל החורש": "https://www.gardenia.net/wp-content/uploads/2023/11/cercis-siliquastrum.webp",
    "פנסית דו-נוצתית": "https://www.udenhout-trees.nl/site/assets/files/1365/koelreuteria_paniculata_boom_bloem_uitbundig_plantsoen.jpg",
    "תפוז וולנסיה": "https://ilan-nursery.co.il/wp-content/smush-webp/2021/02/%D7%AA%D7%A4%D7%95%D7%96-1.jpg.webp",
    "קלסטמון צלולין": "https://www.gardenia.net/wp-content/uploads/2023/11/callistemon-viminalis.webp",
    "ספיון השעווה": "https://www.gardenia.net/wp-content/uploads/2023/11/pistacia-chinensis.webp",
    "בוקיצה סינית": "https://www.gardenia.net/wp-content/uploads/2023/11/zelkova-serrata.webp",
    "בוהיניה מגוונת": "https://www.gardenia.net/wp-content/uploads/2023/11/bauhinia-variegata.webp",
    "פלפלון דמוי אלה": "https://www.gardenia.net/wp-content/uploads/2023/11/schinus-molle.webp",
    "סיגלון": "https://www.gardenia.net/wp-content/uploads/2023/11/jacaranda-mimosifolia.webp",
    "שלטית מקומטת": "https://www.gardenia.net/wp-content/uploads/2023/11/koelreuteria-paniculata.webp",
    "אלת המסטיק": "https://www.gardenia.net/wp-content/uploads/2023/11/pistacia-lentiscus.webp",
    "סיזיגיום מכופף": "https://www.gardenia.net/wp-content/uploads/2023/11/syzygium-paniculatum.webp",
    "דודוניאה": "https://www.gardenia.net/wp-content/uploads/2023/11/dodonaea-viscosa.webp",
    "אוג חרוק": "https://www.gardenia.net/wp-content/uploads/2023/11/rhus-integrifolia.webp",
    "מורן החורש": "https://www.gardenia.net/wp-content/uploads/2023/11/viburnum-tinus.webp",
    "פוטוספורום יפני": "https://www.gardenia.net/wp-content/uploads/2023/11/pittosporum-tobira.webp",
    "המליה מבודרת": "https://www.gardenia.net/wp-content/uploads/2023/11/hamelia-patens.webp",
    "תונברגיה זקופה": "https://www.gardenia.net/wp-content/uploads/2023/11/thunbergia-erecta.webp",
    "קריסה דרומית": "https://www.gardenia.net/wp-content/uploads/2023/11/carissa-macrocarpa.webp",
    "דורנטה תאילנדית": "https://www.gardenia.net/wp-content/uploads/2023/11/duranta-erecta.webp",
    "לויקופילום": "https://www.gardenia.net/wp-content/uploads/2023/11/leucophyllum-frutescens.webp",
    "בן עוזרר הודי": "https://www.gardenia.net/wp-content/uploads/2023/11/grewia-occidentalis.webp",
    "יסמין אסייתי": "https://www.gardenia.net/wp-content/uploads/2023/11/jasminum-sambac.webp",
    "גארדניה יסמינית": "https://www.gardenia.net/wp-content/uploads/2023/11/gardenia-jasminoides.webp",
    "פלומריה ריחנית": "https://www.gardenia.net/wp-content/uploads/2023/11/plumeria-rubra.webp",
    "סולינום רנטונט": "https://www.gardenia.net/wp-content/uploads/2023/11/solanum-rantonnetii.webp",
    "היביסקוס סיני": "https://www.gardenia.net/wp-content/uploads/2023/11/hibiscus-rosa-sinensis.webp",
    "מוראיה מכבדית": "https://www.gardenia.net/wp-content/uploads/2023/11/murraya-paniculata.webp",
    "אגפנתוס אפריקאי": "https://www.gardenia.net/wp-content/uploads/2023/11/agapanthus-africanus.webp",
    "ברונפלסיה": "https://www.gardenia.net/wp-content/uploads/2023/11/brunfelsia-pauciflora.webp",
    "מלינית": "https://www.gardenia.net/wp-content/uploads/2023/11/callicarpa-bodinieri.webp",
    "וינקה זקופה": "https://www.gardenia.net/wp-content/uploads/2023/11/catharanthus-roseus.webp",
    "גרניום פלרגוניום": "https://www.gardenia.net/wp-content/uploads/2023/11/pelargonium-hortorum.webp",
    "פטוניה": "https://www.gardenia.net/wp-content/uploads/2023/11/petunia.webp",
    "אמנון ותמר": "https://www.gardenia.net/wp-content/uploads/2023/11/cyclamen-persicum.webp",
    "מרווה": "https://www.gardenia.net/wp-content/uploads/2023/11/salvia-nemorosa.webp",
    "גזניה": "https://www.gardenia.net/wp-content/uploads/2023/11/gazania-rigens.webp",
    "ציניה": "https://www.gardenia.net/wp-content/uploads/2023/11/zinnia-elegans.webp",
    "לבנדר": "https://www.gardenia.net/wp-content/uploads/2023/11/lavandula-angustifolia.webp",
    "גרברה": "https://www.gardenia.net/wp-content/uploads/2023/11/gerbera-jamesonii.webp",
    "בגוניה": "https://www.gardenia.net/wp-content/uploads/2023/11/begonia-semperflorens.webp",
    "דיכונדרה מכסיפה": "https://www.gardenia.net/wp-content/uploads/2023/11/dichondra-argentea.webp",
    "דשא יפני": "https://www.gardenia.net/wp-content/uploads/2023/11/zoysia-japonica.webp",
    "גזניה זוחלת": "https://www.gardenia.net/wp-content/uploads/2023/11/gazania-rigens.webp",
    "אפטניה לבבית": "https://www.gardenia.net/wp-content/uploads/2023/11/aptenia-cordifolia.webp",
    "ורבנה זוחלת": "https://www.gardenia.net/wp-content/uploads/2023/11/verbena-peruviana.webp",
    "רוזמרין זוחל": "https://www.gardenia.net/wp-content/uploads/2023/11/rosmarinus-officinalis.webp",
    "ערער זוחל": "https://www.gardenia.net/wp-content/uploads/2023/11/juniperus-horizontalis.webp",
    "אריגרון": "https://www.gardenia.net/wp-content/uploads/2023/11/erigeron-karvinskianus.webp",
    "טרכלוספרמון יסמיני": "https://www.gardenia.net/wp-content/uploads/2023/11/trachelospermum-jasminoides.webp",
    "פסיפלורה": "https://www.gardenia.net/wp-content/uploads/2023/11/passiflora-edulis.webp",
    "בוגנוויליה": "https://www.gardenia.net/wp-content/uploads/2023/11/bougainvillea.webp",
    "ויסטריה סינית": "https://www.gardenia.net/wp-content/uploads/2023/11/wisteria-sinensis.webp",
    "יסמין רפואי": "https://www.gardenia.net/wp-content/uploads/2023/11/jasminum-officinale.webp",
    "אלמנדה צהובה": "https://www.gardenia.net/wp-content/uploads/2023/11/allamanda-cathartica.webp",
    "יערה יפנית": "https://www.gardenia.net/wp-content/uploads/2023/11/lonicera-japonica.webp",
    "מנדווילה": "https://www.gardenia.net/wp-content/uploads/2023/11/mandevilla.webp",
    "מונסטרה דליסיוסה": "https://www.gardenia.net/wp-content/uploads/2023/11/monstera-deliciosa.webp",
    "ציפור גן עדן ניקולאי": "https://www.gardenia.net/wp-content/uploads/2023/11/strelitzia-nicolai.webp",
    "אלוקסיה": "https://www.gardenia.net/wp-content/uploads/2023/11/alocasia-macrorrhiza.webp",
    "פילודנדרון": "https://www.gardenia.net/wp-content/uploads/2023/11/philodendron-bipinnatifidum.webp",
    "דקלי חמדוריאה": "https://www.gardenia.net/wp-content/uploads/2023/11/chamaedorea-elegans.webp",
    "שפלרה": "https://www.gardenia.net/wp-content/uploads/2023/11/schefflera-arboricola.webp",
    "סנסיווירה": "https://www.gardenia.net/wp-content/uploads/2023/11/dracaena-trifasciata.webp",
    "קרוטון": "https://www.gardenia.net/wp-content/uploads/2023/11/codiaeum-variegatum.webp",
    "ברומליה": "https://www.gardenia.net/wp-content/uploads/2023/11/bromeliaceae.webp",
    "זיף-נוצה רוברה": "https://www.gardenia.net/wp-content/uploads/2023/11/pennisetum-setaceum.webp",
    "מיסקנתוס סיני": "https://www.gardenia.net/wp-content/uploads/2023/11/miscanthus-sinensis.webp",
    "נסלה": "https://www.gardenia.net/wp-content/uploads/2023/11/nassella-tenuissima.webp",
    "דיאטס": "https://www.gardenia.net/wp-content/uploads/2023/11/dietes-bicolor.webp",
    "ליריופה": "https://www.gardenia.net/wp-content/uploads/2023/11/liriope-muscari.webp",
    "אגפנתוס פיטר פן": "https://www.gardenia.net/wp-content/uploads/2023/11/agapanthus-africanus.webp",
    "לואיזה": "https://www.gardenia.net/wp-content/uploads/2023/11/aloysia-citrodora.webp",
    "רוזמרין": "https://www.gardenia.net/wp-content/uploads/2023/11/rosmarinus-officinalis.webp",
    "נענע": "https://www.gardenia.net/wp-content/uploads/2023/11/mentha.webp",
    "זוטה לבנה": "https://www.gardenia.net/wp-content/uploads/2023/11/micromeria-fruticosa.webp",
    "מרווה רפואית": "https://www.gardenia.net/wp-content/uploads/2023/11/salvia-officinalis.webp",
    "זעטר": "https://www.gardenia.net/wp-content/uploads/2023/11/thymbra-spicata.webp",
    "בזיל": "https://www.gardenia.net/wp-content/uploads/2023/11/ocimum-basilicum.webp",
    "טימין": "https://www.gardenia.net/wp-content/uploads/2023/11/thymus-vulgaris.webp",
    "לבנדר צמח תועלת": "https://www.gardenia.net/wp-content/uploads/2023/11/lavandula-angustifolia.webp",
    "גרניום לימוני": "https://www.gardenia.net/wp-content/uploads/2023/11/pelargonium-crispum.webp",
    "לימונית": "https://www.gardenia.net/wp-content/uploads/2023/11/cymbopogon-citratus.webp",
}

HTML_FILE = "OUTROOT_מגדיר_צמחים.html"

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Referer': 'https://www.gardenia.net/'
}

def download_image(url):
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200 and len(r.content) > 1000:
            ext = 'webp' if 'webp' in url else 'jpg'
            b64 = base64.b64encode(r.content).decode()
            return f"data:image/{ext};base64,{b64}"
    except Exception as e:
        print(f"  Error: {e}")
    return None

print("מוריד תמונות...")
print("=" * 50)

with open(HTML_FILE, 'r', encoding='utf-8') as f:
    html = f.read()

downloaded = 0
failed = []

for plant_name, url in PLANT_URLS.items():
    print(f"[{downloaded+1}/{len(PLANT_URLS)}] {plant_name}...")
    
    img_data = download_image(url)
    
    if img_data:
        # Find plant in HTML by first word match and replace img
        first_word = plant_name.split()[0]
        pattern = rf'({{id:\d+,cat:"[^"]+",name:"[^"]*{re.escape(first_word)}[^"]*"[^}}]+img:")[^"]*("}})'
        new_html = re.sub(pattern, rf'\g<1>{img_data}\g<2>', html)
        if new_html != html:
            html = new_html
            downloaded += 1
            print(f"  ✅ הורד ({len(img_data)//1024}KB)")
        else:
            print(f"  ⚠️ לא נמצא בקובץ")
    else:
        failed.append(plant_name)
        print(f"  ❌ נכשל")
    
    time.sleep(0.3)  # נימוסי

print("\n" + "=" * 50)
print(f"✅ הורדו: {downloaded}")
print(f"❌ נכשלו: {len(failed)}")
if failed:
    print("נכשלו:", failed)

with open(HTML_FILE, 'w', encoding='utf-8') as f:
    f.write(html)

print(f"\nנשמר! גודל: {len(html)/1024/1024:.1f}MB")
print("הקובץ מוכן לשליחה בוואטסאפ!")
